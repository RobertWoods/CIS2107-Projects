/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package brandisstalker;

import java.io.IOException;
import static java.lang.Thread.sleep;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;
import java.util.Scanner;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author Robert
 */
public class BrandisStalker {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, JSONException, InterruptedException {
        int posts = getNumPosts();
        System.out.println("Number of posts: "+posts+"\n");
        int second = 1000;
        int minute = second*60;
        while(1==1){
            sleep(10*minute);
            System.out.println("Checking post status");
            int newNumPosts = getNumPosts();
            if(newNumPosts>posts){
                System.out.println("BRANDIS DID SOMETHING");
                sendEmail();
            }
            posts = newNumPosts;
            System.out.println("Number of posts: "+posts+"\n");
        }

    }
    
    public static int getNumPosts() throws MalformedURLException, IOException, JSONException{
        URL url = new URL("http://api.tumblr.com/v2/blog/bwstickles.tumblr.com/info?api_key=fuiKNFp9vQFvjLNvx4sUwti4Yb5yGutBN4Xh10LXZhhRKjWlV4");
        Scanner scan = new Scanner(url.openStream());
        String str = "";
        while (scan.hasNext()) {
            str += scan.next();
        }
        scan.close();
        JSONObject obj = new JSONObject(str);
        JSONObject obj1 = obj.getJSONObject("response");
        JSONObject obj2 = obj1.getJSONObject("blog");
        return obj2.getInt("posts");
    }
    
    public static void sendEmail(){
        final String username = "tuf08373@temple.edu";
        final String password = "524379tRebor0";

        Properties props = new Properties();
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
          new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
          });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("tuf08373@gmail.com"));
            message.setRecipients(Message.RecipientType.TO,
                InternetAddress.parse("tuf08373@temple.edu"));
            message.setSubject("brandis tumblr");
            message.setText("Brandis posted to tumblr!");

            Transport.send(message);

            System.out.println("Email sent");

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
    }
    
}
